package com.packtpub.felix.bookshelf.service.tui;

public class InvalidCommandAttributesRuntimeException extends RuntimeException
{

    private static final long serialVersionUID = -7850057307473924364L;

    public InvalidCommandAttributesRuntimeException(String message) {
        super(message);
    }
}
